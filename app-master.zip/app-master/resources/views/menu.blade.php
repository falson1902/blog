<div class="row">
    <div class="col-sm-2"></div>
          <div class="col-sm-8">
<nav class='main-menu'>
    
       
<ul>
    <a href="{{route('category.get')}}"><li class='left'>Categories</li></a>
</ul>
</nav>
          </div>
               <div class="col-sm-2"></div>
</div>
