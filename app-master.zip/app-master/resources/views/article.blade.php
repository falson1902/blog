

@extends('welcome')
@section('content')

@stop